SELECT * FROM code_huntersdb.employer
WHERE languages_needed like '%et%';
