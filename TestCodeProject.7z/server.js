
var express = require("express");
var exphbs = require('express-handlebars');
var compression = require('compression')


var app = express();
var PORT = process.env.PORT || 7070;

app.use(express.static( __dirname + "/public"));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(compression());


app.engine('handlebars', exphbs({defaultLayout:'main'}));
app.set('view engine', 'handlebars');


var routes = require('./controllers/ch_controllers');
app.use(routes)


app.listen(PORT, function() {
  console.log("App listening on PORT " + PORT);
});
